<?php
	session_start();
	
	require ('Fichier.class.php');
	require ('Donnees.class.php');
	require ('Date.class.php');
	require ('Tableau.class.php');
	require ('Graphique.class.php');

	if (!isset($_SESSION['page'])) { $_SESSION['page'] = "dashboard.php"; }
	if (isset( $_GET['page'] )) { $_SESSION['page'] = $_GET['page']; }

	$monfichier = new Fichier ( "", "data", ".csv" );
	$mesdatas = $monfichier->lire_array ();
	$entire = new Donnees ( $mesdatas );
	
	if (!isset($_SESSION['nombre'])) { $_SESSION['nombre'] = $entire->total_lignes(); }
	if (isset( $_GET ['nombre'] )) { $_SESSION['nombre'] = $_GET ['nombre']; }
	
	$troncate = $entire->last ( $_SESSION['nombre'] );
	$mesdonnees = new Donnees ( $troncate );

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Thingspeak by DTA - Dashboard</title>
		<link rel="stylesheet" href="style.css">
	</head>
	<body>
		<div class="header">
			<div class="title">
				<img src="lib/DTA-small.png" alt="Logo DTA small" />
				<h2><a href="#">Thingspeak by DTA - Dashboard</a></h2>
			</div>
			<div class="form">
				<form method="get" action="menu.php" name="mon formulaire">
					<input name="nombre" type="text" id="nombre" placeholder="nombre de lignes" required/>
					<input type="submit" value="Appliquer" />
				</form>
			</div>
			<div class="menu">
				<button id="boutonmenu">Menu</button>
				<div class="sousmenu">
					<a href="menu.php?page=dashboard.php">Dashboard</a>
					<a href="menu.php?page=graphiques.php">Graphiques</a>
					<a href="menu.php?page=dygraph.php">Dygraph</a>
					<a href="menu.php?page=infos.php">Informations</a>
				</div>
			</div>
		</div>
		<div class="main">
			<?php 
				include ($_SESSION['page']);
			?>
		</div>
		<div class="footer">
			<p>© 2016 - Design Tech Académie</p>
		</div>
	</body>
</html>

