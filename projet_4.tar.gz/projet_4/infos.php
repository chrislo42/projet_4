     <div class="infos">
        <h1>Cycle 4 : Site web programmé</h1>
        <p>Présentation du cycle/projet</p>
        <p>Appropriation du sujet</p>
        <p>Répartition des tâches</p>
        <p>To-Do List</p>
      </div>
 