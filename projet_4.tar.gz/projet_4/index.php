<?php
  header('Location: menu.php')
?>
